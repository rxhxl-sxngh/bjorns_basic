#include <iostream>
#include <string>
using std::cin, std::cout, std::endl, std::string;

int main() {


    return 0;
}
