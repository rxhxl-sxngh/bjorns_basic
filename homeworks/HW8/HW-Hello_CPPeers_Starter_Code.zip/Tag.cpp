/*
 *
 * This code is copyrighted (c) 2021 by
 * Texas A&M Computer Science
 *
 *	There will be RIGOROUS cheat checking on your exams!!
 *	DON'T POST ANYWHERE!! such as CHEGG, public Github, etc
 *  You will be legally responsible.
 */

#include <string>
#include <stdexcept>
#include "Tag.h"

using std::string;
using std::vector;

Tag::Tag(string tagName) /* TODO(student): initialize */ {
  // TODO(student): implement constructor checks
}

string Tag::getTagName() {
  // TODO(student): implement getter
}

vector<Post*>& Tag::getTagPosts() {
  // TODO(student): implement getter
}

void Tag::addTagPost(Post* post) {
  // TODO(student): add post to tag posts
}
