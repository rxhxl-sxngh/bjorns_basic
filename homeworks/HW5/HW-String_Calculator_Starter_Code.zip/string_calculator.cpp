#include <iostream>
#include <string>
#include "./string_calculator.h"

using std::cout, std::endl;
using std::string;

unsigned int digit_to_decimal(char digit) {
    // TODO(student): implement
    return 0;
}

char decimal_to_digit(unsigned int decimal) {
    // TODO(student): implement
    return '\0';
}

string trim_leading_zeros(string num) {
    // TODO(student): implement
    return "";
}

string add(string lhs, string rhs) {
    // TODO(student): implement
    return "";
}

string multiply(string lhs, string rhs) {
    // TODO(student): implement
    return "";
}
